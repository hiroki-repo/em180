﻿// dllmain.cpp : DLL アプリケーションのエントリ ポイントを定義します。
#include "pch.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

int iotemp[3] = {0,0,0};

__declspec(dllexport) int __cdecl em180memaccess(int add, int data, int type) {
	switch (type) {
	case 2:
			iotemp[2] = 2;
			iotemp[1] = data;
			iotemp[0] = add;
			while (iotemp[2] != 0) {}
		break;
	case 3:
			iotemp[2] = 3;
			iotemp[1] = 0;
			iotemp[0] = add;
			while (iotemp[2] != 0) {}
			return iotemp[1];
		break;
	case 4:
			iotemp[2] = 4;
			iotemp[1] = 0;
			iotemp[0] = add;
			while (iotemp[2] != 0) {}
		break;
	}
	return 0;
}

int (*em180)(void);

__declspec(dllexport) void setem180(int (*tmp)(void)) { em180 = tmp; }

__declspec(dllexport) void __cdecl startem(int (*tmp)(void)) { while (true) { iotemp[0] = tmp();iotemp[1] = 0;iotemp[2] = 4;while (iotemp[2] != 0) {} } }

__declspec(dllexport) void __cdecl startem2(void) { while (true) { iotemp[0] = em180(); iotemp[1] = 0; iotemp[2] = 4; while (iotemp[2] != 0) {} } }

__declspec(dllexport) void __cdecl startem3(int* tmp) { while (true) { tmp[0] = em180(); tmp[1] = 0; tmp[2] = 4; while (true) { if (tmp[2] == 0) { break; } } } }

__declspec(dllexport) int __cdecl getioaccessptr() { return int(&iotemp[0]); }

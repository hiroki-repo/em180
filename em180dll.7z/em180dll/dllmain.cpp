﻿// dllmain.cpp : DLL アプリケーションのエントリ ポイントを定義します。
#include "pch.h"

#ifdef _MSC_VER
#pragma warning(disable:4996) 
#endif


#ifdef __cplusplus
extern "C" {
#endif

#include "em180.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

int (*em180memaccess) (int,int,int);

__declspec(dllexport) int _em180(void) { return em180(); };

__declspec(dllexport) void setem180memaccess(int (*tmp) (int, int, int)) {
	em180memaccess = tmp;
}

int io_input(int add) {
	return em180memaccess(add, 0, 3);
}

void io_output(int add, int data) {
	em180memaccess(add, data, 2);
}

__declspec(dllexport) int getmainmemptr() {
	return int(&mem);
}

__declspec(dllexport) int getguardptr() {
	return int(&guard);
}

__declspec(dllexport) int getzregptr() {
	return int(&reg);
}

__declspec(dllexport) int getregvalptr(int tmp) {
	switch (tmp) {
	case 0:
		return int(&reg.x.bc);
		break;
	case 1:
		return int(&reg.x.de);
		break;
	case 2:
		return int(&reg.x.hl);
		break;
	case 3:
		return int(&reg.x.af);
		break;
	case 4:
		return int(&reg.x.ix);
		break;
	case 5:
		return int(&reg.x.iy);
		break;
	case 6:
		return int(&reg.x.bc2);
		break;
	case 7:
		return int(&reg.x.de2);
		break;
	case 8:
		return int(&reg.x.hl2);
		break;
	case 9:
		return int(&reg.x.af2);
		break;
	case 10:
		return int(&reg.x.sp);
		break;
	case 11:
		return int(&reg.x.pc);
		break;
	case 12:
		return int(&reg.x.i);
		break;
	case 13:
		return int(&reg.x.r);
		break;
	case 14:
		return int(&reg.x.ie);
		break;
	case 15:
		return int(&reg.x.dmy);
		break;
	case 16:
		return int(&reg.b.b);
		break;
	case 17:
		return int(&reg.b.c);
		break;
	case 18:
		return int(&reg.b.d);
		break;
	case 19:
		return int(&reg.b.e);
		break;
	case 20:
		return int(&reg.b.h);
		break;
	case 21:
		return int(&reg.b.l);
		break;
	case 22:
		return int(&reg.b.a);
		break;
	case 23:
		return int(&reg.b.f);
		break;
	case 24:
		return int(&reg.b.ixh);
		break;
	case 25:
		return int(&reg.b.ixl);
		break;
	case 26:
		return int(&reg.b.iyh);
		break;
	case 27:
		return int(&reg.b.iyl);
		break;
	case 28:
		return int(&reg.b.bc2);
		break;
	case 29:
		return int(&reg.b.de2);
		break;
	case 30:
		return int(&reg.b.hl2);
		break;
	case 31:
		return int(&reg.b.af2);
		break;
	case 32:
		return int(&reg.b.i);
		break;
	case 33:
		return int(&reg.b.r);
		break;
	case 34:
		return int(&reg.b.ie);
		break;
	case 35:
		return int(&reg.b.dmy);
		break;
	}
	return 0;
}


#ifdef __cplusplus
};
#endif
